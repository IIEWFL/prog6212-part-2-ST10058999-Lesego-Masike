﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractMonthlyClaimSystem.Models
{
    public enum ClaimStatus { Pending, Approved, Rejected }

    public class Claim
    {
        public int Id { get; set; }
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public string Notes { get; set; }
        public string SupportingDocumentPath { get; set; }
        public ClaimStatus Status { get; set; } = ClaimStatus.Pending;
        public double TotalAmount => HoursWorked * HourlyRate;
    }
}

