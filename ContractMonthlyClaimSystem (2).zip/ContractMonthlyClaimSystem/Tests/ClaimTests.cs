﻿using ContractMonthlyClaimSystem.Models;
using Xunit;

namespace ContractMonthlyClaimSystem.Tests
{
    public class ClaimTests
    {
        [Fact]
        public void Calculates_Total_Correctly()
        {
            var claim = new Claim { HoursWorked = 10, HourlyRate = 100 };
            Assert.Equal(1000, claim.TotalAmount);
        }

        [Fact]
        public void Default_Status_Is_Pending()
        {
            var claim = new Claim();
            Assert.Equal(ClaimStatus.Pending, claim.Status);
        }
    }
}
