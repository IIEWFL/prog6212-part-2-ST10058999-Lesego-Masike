﻿using System.Collections.Generic;
using System.Linq;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Data
{
    public static class ClaimRepository
    {
        private static readonly List<Claim> Claims = new();

        public static void Add(Claim claim) => Claims.Add(claim);
        public static IEnumerable<Claim> GetAll() => Claims;
        public static Claim? GetById(int id) => Claims.FirstOrDefault(c => c.Id == id);

        public static void UpdateStatus(int id, ClaimStatus status)
        {
            var claim = GetById(id);
            if (claim != null) claim.Status = status;
        }
    }
}
