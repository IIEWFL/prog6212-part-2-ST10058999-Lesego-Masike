﻿using System.Windows;
using ContractMonthlyClaimSystem.Views;

namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            new SubmitClaimWindow().ShowDialog();
        }

        private void ManageClaims_Click(object sender, RoutedEventArgs e)
        {
            new ManagerView().ShowDialog();
        }
    }
}
