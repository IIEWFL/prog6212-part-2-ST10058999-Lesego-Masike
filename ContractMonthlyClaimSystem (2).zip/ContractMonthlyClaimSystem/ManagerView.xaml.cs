﻿using System.Linq;
using System.Windows;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Views
{
    public partial class ManagerView : Window
    {
        public ManagerView()
        {
            InitializeComponent();
            ClaimsGrid.ItemsSource = ClaimRepository.GetAll().ToList();
        }

        private Claim? SelectedClaim => ClaimsGrid.SelectedItem as Claim;

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedClaim != null)
            {
                ClaimRepository.UpdateStatus(SelectedClaim.Id, ClaimStatus.Approved);
                ClaimsGrid.Items.Refresh();
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedClaim != null)
            {
                ClaimRepository.UpdateStatus(SelectedClaim.Id, ClaimStatus.Rejected);
                ClaimsGrid.Items.Refresh();
            }
        }
    }
}
