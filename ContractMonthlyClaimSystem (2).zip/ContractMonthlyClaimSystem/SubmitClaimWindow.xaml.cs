﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using Microsoft.Win32;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Views
{
    public partial class SubmitClaimWindow : Window
    {
        private string? uploadedFile;

        public SubmitClaimWindow()
        {
            InitializeComponent();
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Filter = "Documents (*.pdf;*.docx;*.xlsx)|*.pdf;*.docx;*.xlsx",
                Title = "Select Supporting Document"
            };

            if (dlg.ShowDialog() == true)
            {
                uploadedFile = dlg.FileName;
                FileNameText.Text = Path.GetFileName(uploadedFile);
            }
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LecturerNameBox.Text))
            {
                MessageBox.Show("Please enter the lecturer's name.");
                return;
            }

            if (!double.TryParse(HoursBox.Text, out double hours) || hours <= 0)
            {
                MessageBox.Show("Please enter a valid number of hours.");
                return;
            }

            if (!double.TryParse(RateBox.Text, out double rate) || rate <= 0)
            {
                MessageBox.Show("Please enter a valid hourly rate.");
                return;
            }

            try
            {
                var claim = new Claim
                {
                    // Prefer repository auto-ID or DB auto-increment
                    Id = ClaimRepository.GetAll().Any() ? ClaimRepository.GetAll().Max(c => c.Id) + 1 : 1,
                    LecturerName = LecturerNameBox.Text.Trim(),
                    HoursWorked = hours,
                    HourlyRate = rate,
                    Notes = NotesBox.Text?.Trim(),
                    SupportingDocumentPath = uploadedFile ?? string.Empty
                };

                ClaimRepository.Add(claim);
                MessageBox.Show("Claim submitted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to submit claim: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
