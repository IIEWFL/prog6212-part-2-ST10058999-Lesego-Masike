﻿using Microsoft.AspNetCore.Mvc;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;
using Microsoft.AspNetCore.Http;
using System.IO;
using System;

namespace ContractMonthlyClaimSystem.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly string _uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Claims = ClaimRepository.GetAll();
            return View();
        }

        [HttpPost]
        public IActionResult SubmitClaim(Claim model, IFormFile supportingDocument)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Claims = ClaimRepository.GetAll();
                return View("Index", model);
            }

            if (supportingDocument != null)
            {
                if (!IsValidFile(supportingDocument))
                {
                    ModelState.AddModelError("supportingDocument", "Invalid file type or size exceeds 5MB.");
                    ViewBag.Claims = ClaimRepository.GetAll();
                    return View("Index", model);
                }

                var filePath = Path.Combine(_uploadPath, supportingDocument.FileName);
                Directory.CreateDirectory(_uploadPath);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    supportingDocument.CopyTo(stream);
                }
                model.SupportingDocumentPath = $"/uploads/{supportingDocument.FileName}";
            }

            model.Id = ClaimRepository.GetAll().Any() ? ClaimRepository.GetAll().Max(c => c.Id) + 1 : 1;
            ClaimRepository.Add(model);
            ViewBag.Claims = ClaimRepository.GetAll();
            return View("Index");
        }

        [HttpPost]
        public IActionResult UpdateStatus(int id, ClaimStatus status)
        {
            ClaimRepository.UpdateStatus(id, status);
            return RedirectToAction("Index");
        }

        private bool IsValidFile(IFormFile file)
        {
            var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx" };
            var maxSize = 5 * 1024 * 1024; // 5MB
            var ext = Path.GetExtension(file.FileName).ToLower();
            return file.Length <= maxSize && allowedExtensions.Contains(ext);
        }
    }
}