﻿using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models
{
    public enum ClaimStatus { Pending, Approved, Rejected }

    public class Claim
    {
        public int Id { get; set; }
        [Required]
        public string LecturerName { get; set; } = string.Empty;
        [Required, Range(0.1, 1000)]
        public double HoursWorked { get; set; } = 0.0;
        [Required, Range(0.1, 1000)]
        public double HourlyRate { get; set; } = 0.0;
        public string Notes { get; set; } = string.Empty;
        public string SupportingDocumentPath { get; set; } = string.Empty;
        public ClaimStatus Status { get; set; } = ClaimStatus.Pending;
        public double TotalAmount => HoursWorked * HourlyRate;
    }
}